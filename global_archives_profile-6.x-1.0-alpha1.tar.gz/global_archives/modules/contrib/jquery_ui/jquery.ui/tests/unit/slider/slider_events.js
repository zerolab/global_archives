/*
 * slider_events.js
 */
(function($) {

module("slider: events");

test("start", function() {
	ok(false, "missing test - untested code is broken code.");
});

test("slide", function() {
	ok(false, "missing test - untested code is broken code.");
});

test("change", function() {
	ok(false, "missing test - untested code is broken code.");
});

test("stop", function() {
	ok(false, "missing test - untested code is broken code.");
});

})(jQuery);
