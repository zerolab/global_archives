/*
 * selectable_tickets.js
 */
(function($) {

module("selectable: tickets");

})(jQuery);
